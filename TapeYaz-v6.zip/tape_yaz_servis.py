# -*- coding: utf-8 -*-
"""
Tape Yaz - Bilgisayar Servisi
Yalnizca bu bilgisayarda (127.0.0.1) calisir; ses dosyasi internete gonderilmez.
  - Ses -> metin : faster-whisper (islemci, int8)
  - Konusmaci ayirma : sherpa-onnx (pyannote segmentation + 3D-Speaker embedding)
Uygulama (index.html) bu servise http://127.0.0.1:8765 adresinden baglanir.
"""
import json
import os
import sys
import tempfile
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

HOST, PORT = "127.0.0.1", 8765
VERSION = "1.2"
BASE = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE, "modeller")
os.makedirs(MODEL_DIR, exist_ok=True)
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

WHISPER_MODELS = ("base", "small", "medium", "large-v3-turbo")
SEG_MODEL = ("csukuangfj/sherpa-onnx-pyannote-segmentation-3-0", "model.onnx")
EMB_MODEL = ("csukuangfj/speaker-embedding-models",
             "3dspeaker_speech_campplus_sv_zh_en_16k-common_advanced.onnx")
THREADS = max(2, min(8, os.cpu_count() or 4))

JOB = threading.Lock()
_model = {"name": None, "obj": None}


def log(*a):
    print(time.strftime("[%H:%M:%S]"), *a, flush=True)


def diar_available():
    try:
        import sherpa_onnx  # noqa: F401
        return True
    except Exception:
        return False


def _frames(x):
    """PyAV surumlerine gore AudioResampler.resample ciktisini listeye cevirir."""
    if x is None:
        return []
    return list(x) if isinstance(x, (list, tuple)) else [x]


def _decode_av(path):
    """PyAV ile 16 kHz tek kanal float32. PyAV'in eski ve yeni surumlerinde calisir."""
    import av
    import numpy as np
    try:
        container = av.open(path, mode="r", metadata_errors="ignore")
    except TypeError:  # eski PyAV: metadata_errors yok
        container = av.open(path, mode="r")
    try:
        stream = next((s for s in container.streams if s.type == "audio"), None)
        if stream is None:
            raise RuntimeError("Dosyada ses kanalı bulunamadı.")
        rs = av.AudioResampler(format="s16", layout="mono", rate=16000)
        parts = []
        for frame in container.decode(stream):
            for f in _frames(rs.resample(frame)):
                parts.append(f.to_ndarray().reshape(-1))
        try:
            for f in _frames(rs.resample(None)):
                parts.append(f.to_ndarray().reshape(-1))
        except Exception:
            pass
    finally:
        container.close()
    if not parts:
        raise RuntimeError("Ses çözülemedi (dosya boş veya desteklenmeyen biçim).")
    return np.concatenate(parts).astype(np.float32) / 32768.0


def _decode_ffmpeg(path):
    import shutil
    import subprocess
    import numpy as np
    exe = shutil.which("ffmpeg")
    if not exe:
        raise RuntimeError("ffmpeg bulunamadı.")
    r = subprocess.run([exe, "-nostdin", "-v", "error", "-i", path, "-f", "s16le",
                        "-ac", "1", "-ar", "16000", "-"], capture_output=True)
    if r.returncode != 0 or not r.stdout:
        raise RuntimeError(r.stderr.decode("utf-8", "replace").strip() or "ffmpeg ses çözemedi.")
    return np.frombuffer(r.stdout, np.int16).astype(np.float32) / 32768.0


def decode_samples(path):
    """Once kendi PyAV kodumuz, olmazsa faster-whisper'in cozucusu, olmazsa ffmpeg."""
    errs = []
    for name, fn in (("PyAV", _decode_av), ("faster-whisper", None), ("ffmpeg", _decode_ffmpeg)):
        try:
            if fn is None:
                from faster_whisper.audio import decode_audio
                return decode_audio(path, sampling_rate=16000)
            return fn(path)
        except Exception as e:
            errs.append("%s: %s" % (name, e))
            log("Ses cozme yontemi basarisiz ->", errs[-1])
    raise RuntimeError("Ses çözülemedi. " + " | ".join(errs))


def _has_file(repo, filename):
    snap = os.path.join(MODEL_DIR, "models--" + repo.replace("/", "--"), "snapshots")
    try:
        return any(os.path.exists(os.path.join(snap, h, filename)) for h in os.listdir(snap))
    except OSError:
        return False


def downloaded_models():
    """Daha once indirilmis Whisper modelleri (modeller klasorune bakar)."""
    found = set()
    try:
        for d in os.listdir(MODEL_DIR):
            if not d.startswith("models--"):
                continue
            for name in WHISPER_MODELS:
                if d.endswith("faster-whisper-" + name):
                    snap = os.path.join(MODEL_DIR, d, "snapshots")
                    try:
                        if any(os.path.exists(os.path.join(snap, h, "model.bin")) for h in os.listdir(snap)):
                            found.add(name)
                    except OSError:
                        pass
    except OSError:
        pass
    return sorted(found)


def diar_ready():
    return _has_file(SEG_MODEL[0], SEG_MODEL[1]) and _has_file(EMB_MODEL[0], EMB_MODEL[1])


def get_model(name):
    if _model["name"] != name:
        from faster_whisper import WhisperModel
        _model["obj"] = None
        _model["name"] = None
        log("Whisper modeli yukleniyor:", name, "(ilk seferde indirilir)")
        _model["obj"] = WhisperModel(name, device="cpu", compute_type="int8",
                                     cpu_threads=THREADS, download_root=MODEL_DIR)
        _model["name"] = name
    return _model["obj"]


def diar_files():
    from huggingface_hub import hf_hub_download
    seg = hf_hub_download(repo_id=SEG_MODEL[0], filename=SEG_MODEL[1], cache_dir=MODEL_DIR)
    emb = hf_hub_download(repo_id=EMB_MODEL[0], filename=EMB_MODEL[1], cache_dir=MODEL_DIR)
    return seg, emb


def diarize(samples, num_speakers, progress):
    """[(baslangic, bitis, konusmaci_no)] dondurur; konusmaci no ilk gorunme sirasina gore 0,1,2..."""
    import sherpa_onnx
    seg, emb = diar_files()

    def mk(cls, **kw):
        try:
            return cls(num_threads=THREADS, **kw)
        except TypeError:
            return cls(**kw)

    cfg = sherpa_onnx.OfflineSpeakerDiarizationConfig(
        segmentation=mk(sherpa_onnx.OfflineSpeakerSegmentationModelConfig,
                        pyannote=sherpa_onnx.OfflineSpeakerSegmentationPyannoteModelConfig(model=seg)),
        embedding=mk(sherpa_onnx.SpeakerEmbeddingExtractorConfig, model=emb),
        clustering=sherpa_onnx.FastClusteringConfig(
            num_clusters=num_speakers if num_speakers > 0 else -1, threshold=0.5),
        min_duration_on=0.3,
        min_duration_off=0.5,
    )
    if not cfg.validate():
        raise RuntimeError("Konuşmacı ayırma modelleri bulunamadı veya geçersiz.")
    sd = sherpa_onnx.OfflineSpeakerDiarization(cfg)

    def cb(done, total):
        try:
            progress(done, total)
        except Exception:
            return 1
        return 0

    try:
        res = sd.process(samples, callback=cb)
    except TypeError:
        res = sd.process(samples)
    res = res.sort_by_start_time()
    order, turns = {}, []
    for r in res:
        k = int(r.speaker)
        if k not in order:
            order[k] = len(order)
        turns.append((float(r.start), float(r.end), order[k]))
    return turns


def speaker_for(turns, s, e):
    best, bo = None, 0.0
    for ts, te, k in turns:
        if te <= s:
            continue
        if ts >= e:
            break
        o = min(e, te) - max(s, ts)
        if o > bo:
            bo, best = o, k
    if best is None and turns:
        mid = (s + e) / 2.0
        best = min(turns, key=lambda t: abs((t[0] + t[1]) / 2.0 - mid))[2]
    return best


class Out:
    """Satir satir JSON (ndjson) yayini. Istemci kopunca ConnectionAbortedError firlatir."""

    def __init__(self, handler):
        self.h = handler
        self.dead = False

    def __call__(self, obj):
        if self.dead:
            raise ConnectionAbortedError()
        try:
            self.h.wfile.write((json.dumps(obj, ensure_ascii=False) + "\n").encode("utf-8"))
            self.h.wfile.flush()
        except (BrokenPipeError, ConnectionError, OSError):
            self.dead = True
            raise ConnectionAbortedError()


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"

    def log_message(self, *a):
        pass

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "600")

    def _json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    def _stream_start(self):
        self.send_response(200)
        self.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Accel-Buffering", "no")
        self._cors()
        self.end_headers()
        return Out(self)

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        if urlparse(self.path).path == "/ping":
            self._json(200, {"ok": True, "version": VERSION, "diar": diar_available(),
                             "models": list(WHISPER_MODELS),
                             "downloaded": downloaded_models(), "diar_ready": diar_ready()})
        else:
            self._json(404, {"ok": False})

    def do_POST(self):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        try:
            if u.path == "/transcribe":
                self._transcribe(q)
            elif u.path == "/prepare":
                self._prepare(q)
            else:
                self._json(404, {"ok": False})
        except ConnectionAbortedError:
            log("Istemci baglantiyi kesti / islem iptal edildi.")
        except Exception:
            log("BEKLENMEYEN HATA:\n" + traceback.format_exc())

    # ---- ses dosyasini gecici dosyaya al ----
    def _read_body(self):
        n = int(self.headers.get("Content-Length", "0") or 0)
        if n <= 0:
            return None
        fd, path = tempfile.mkstemp(prefix="tapeyaz_", suffix=".bin")
        left = n
        with os.fdopen(fd, "wb") as f:
            while left > 0:
                chunk = self.rfile.read(min(1 << 20, left))
                if not chunk:
                    break
                f.write(chunk)
                left -= len(chunk)
        return path

    def _prepare(self, q):
        model = q.get("model", "small")
        out = self._stream_start()
        if model not in WHISPER_MODELS:
            return out({"t": "err", "msg": "Bilinmeyen model: " + model})
        if not JOB.acquire(blocking=False):
            return out({"t": "err", "msg": "Servis başka bir işlemle meşgul."})
        try:
            out({"t": "stat", "msg": "Model hazırlanıyor (indirme birkaç dakika sürebilir)…"})
            get_model(model)
            if q.get("diar") == "1":
                out({"t": "stat", "msg": "Konuşmacı ayırma modelleri hazırlanıyor…"})
                try:
                    diar_files()
                except Exception as e:
                    out({"t": "warn", "msg": "Konuşmacı ayırma modelleri indirilemedi: " + str(e)})
            out({"t": "done"})
        except ConnectionAbortedError:
            raise
        except Exception as e:
            log(traceback.format_exc())
            out({"t": "err", "msg": str(e)})
        finally:
            JOB.release()

    def _transcribe(self, q):
        model = q.get("model", "small")
        lang = q.get("lang") or None
        start = float(q.get("from", "0") or 0)
        spk_opt = int(q.get("spk", "-1") or -1)  # -1 kapali, 0 otomatik, N kisi
        path = self._read_body()
        out = self._stream_start()
        if path is None:
            return out({"t": "err", "msg": "Boş dosya gönderildi."})
        if model not in WHISPER_MODELS:
            os.remove(path)
            return out({"t": "err", "msg": "Bilinmeyen model: " + model})
        if not JOB.acquire(blocking=False):
            os.remove(path)
            return out({"t": "err", "msg": "Servis başka bir işlemle meşgul; bitmesini bekleyin."})
        try:
            out({"t": "stat", "msg": "Ses çözülüyor…"})
            samples = decode_samples(path)
            total = len(samples) / 16000.0
            log("Dosya:", round(total), "sn, model:", model, "dil:", lang, "konusmaci:", spk_opt)

            turns = []
            if spk_opt >= 0:
                out({"t": "stat", "msg": "Konuşmacılar ayırt ediliyor… (uzun sürebilir)"})
                last = [0]

                def dprog(done, tot):
                    pct = int(done * 100 / tot) if tot else 0
                    if pct != last[0]:
                        last[0] = pct
                        out({"t": "dprog", "pct": pct})

                try:
                    turns = diarize(samples, spk_opt, dprog)
                    n = len(set(t[2] for t in turns))
                    out({"t": "stat", "msg": "%d konuşmacı bulundu." % n})
                except ConnectionAbortedError:
                    raise
                except Exception as e:
                    log(traceback.format_exc())
                    out({"t": "warn", "msg": "Konuşmacı ayırma yapılamadı, metin konuşmacısız devam ediyor: " + str(e)})
                    turns = []

            out({"t": "stat", "msg": "Model yükleniyor… (ilk seferde indirilir)"})
            wm = get_model(model)
            out({"t": "stat", "msg": "Çözümleniyor…"})
            kw = dict(language=lang, task="transcribe", vad_filter=True,
                      vad_parameters=dict(min_silence_duration_ms=500),
                      beam_size=5, condition_on_previous_text=False)
            if start > 0:
                kw["clip_timestamps"] = [float(start)]
            segments, _info = wm.transcribe(samples, **kw)
            for sg in segments:
                text = (sg.text or "").strip()
                if text and not (getattr(sg, "no_speech_prob", 0) > 0.7 and getattr(sg, "avg_logprob", 0) < -1.0):
                    out({"t": "seg", "s": round(float(sg.start), 2), "e": round(float(sg.end), 2),
                         "text": text,
                         "spk": speaker_for(turns, float(sg.start), float(sg.end)) if turns else None})
                out({"t": "prog", "pos": round(float(sg.end), 2), "total": round(total, 2)})
            out({"t": "done"})
        except ConnectionAbortedError:
            raise
        except Exception as e:
            log(traceback.format_exc())
            try:
                out({"t": "err", "msg": str(e)})
            except ConnectionAbortedError:
                pass
        finally:
            JOB.release()
            try:
                os.remove(path)
            except OSError:
                pass


def main():
    print("=" * 60)
    print(" Tape Yaz - Bilgisayar Servisi  v" + VERSION)
    print("=" * 60)
    ThreadingHTTPServer.daemon_threads = True
    try:
        srv = ThreadingHTTPServer((HOST, PORT), Handler)
    except OSError:
        print("HATA: %d numarali baglanti noktasi kullanimda. Servis zaten acik olabilir." % PORT)
        sys.exit(1)
    print(" Hazir: http://%s:%d" % (HOST, PORT))
    print(" Konusmaci ayirma:", "hazir" if diar_available() else "KURULU DEGIL (sherpa-onnx eksik)")
    print(" Bu pencereyi KAPATMAYIN. Kapatinca servis durur.")
    print(" Tape Yaz uygulamasina donup 'Sesi Metne Cevir' penceresini acin.")
    print("=" * 60)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
