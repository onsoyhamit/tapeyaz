@echo off
chcp 65001 >nul
title Tape Yaz - Bilgisayar Servisi
cd /d "%~dp0"

if exist ".venv\Scripts\python.exe" goto CALISTIR

echo ============================================================
echo  Ilk kurulum yapiliyor (yalnizca bir kez, birkac dakika surer)
echo ============================================================
set "PY="
py -3.12 --version >nul 2>nul && set "PY=py -3.12"
if not defined PY py -3.11 --version >nul 2>nul && set "PY=py -3.11"
if not defined PY py -3.10 --version >nul 2>nul && set "PY=py -3.10"
if not defined PY py -3 --version >nul 2>nul && set "PY=py -3"
if not defined PY python --version >nul 2>nul && set "PY=python"
if not defined PY goto PYYOK

%PY% -m venv .venv
if errorlevel 1 goto HATA
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto HATA
echo.
echo Kurulum tamamlandi.
echo.

:CALISTIR
echo Paketler kontrol ediliyor (guncelse birkac saniye surer)...
".venv\Scripts\python.exe" -m pip install -q --disable-pip-version-check -r requirements.txt
if errorlevel 1 echo [UYARI] Paket guncellemesi yapilamadi (internet yok olabilir). Mevcut kurulumla devam ediliyor.
set PYTHONUTF8=1
set HF_HUB_DISABLE_SYMLINKS_WARNING=1
".venv\Scripts\python.exe" tape_yaz_servis.py
echo.
echo Servis durdu.
pause
exit /b 0

:PYYOK
echo.
echo Python bulunamadi.
echo 1) https://www.python.org/downloads/ adresinden Python 3.12 indirin.
echo 2) Kurulumda "Add python.exe to PATH" kutusunu ISARETLEYIN.
echo 3) Kurulumdan sonra bu dosyayi tekrar cift tiklayin.
echo.
pause
exit /b 1

:HATA
echo.
echo Kurulum sirasinda hata olustu. Internet baglantinizi kontrol edip dosyayi tekrar calistirin.
echo Sorun surerse ".venv" klasorunu silip tekrar deneyin.
echo.
pause
exit /b 1
